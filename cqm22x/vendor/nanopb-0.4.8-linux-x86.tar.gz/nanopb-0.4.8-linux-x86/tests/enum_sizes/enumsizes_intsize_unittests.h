#pragma once

int TestIntSize();